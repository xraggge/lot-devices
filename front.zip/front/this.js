const client = mqtt.connect('ws://localhost:9001');  

client.on('connect', function () {
    console.log('Connected to MQTT broker');
    client.subscribe('device/data');  
});

document.getElementById('onBut').addEventListener('click', function () {
    client.publish('device/control', 'on');  
});

document.getElementById('offBut').addEventListener('click', function () {
    client.publish('device/control', 'off');  
});

document.getElementById('getData').addEventListener('click', function () {
    client.publish('device/getData', 'request');  
});


client.on('message', function (topic, message) {
    if (topic === 'device/data') {
        document.getElementById('Display').innerText = 'Data: ' + message.toString();  
    }
});

